package com.firebow.event;

import com.firebow.util.*;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * FireBowRuntime v6 — rail là một job có state machine.
 *
 *   SEND   : chờ rotation tick này được áp → interact rail
 *   VERIFY : rail phải sống đủ "window" tick (≈ ping/50 + 2) để server kịp revert nếu từ chối.
 *            rail mất → quay lại SEND (tối đa MAX_PLACE_ATTEMPTS lần)
 *   CART   : rail đã ổn định → đặt TNT minecart. Xong thì kết thúc job.
 *
 * Mọi thao tác đều chạy trên main thread (arrow tick + END_CLIENT_TICK).
 */
public final class FireBowRuntime {

    private static final FireBowRuntime INSTANCE = new FireBowRuntime();
    public static FireBowRuntime get() { return INSTANCE; }

    private static final long ARROW_TTL          = 3000L;
    private static final int  MAX_PLACE_ATTEMPTS = 4;
    private static final int  MAX_WAIT          = 3;    // tick chờ trước khi bỏ bước hiện tại
    private static final int  MAX_JOB_TICKS     = 80;   // hết giờ cho cả job

    private enum Phase { SEND, VERIFY, CART }

    private static final class RailJob {
        final BlockPos pos;
        Phase phase      = Phase.SEND;
        int   attempts   = 0;  // số lần đã gửi interact
        int   ticks      = 0;  // tick đếm trong phase hiện tại
        int   window     = 0;  // số tick rail phải sống trước khi đặt cart
        int   totalTicks = 0;

        RailJob(BlockPos pos) { this.pos = pos; }
    }

    private final Map<Integer, Long> acceptedArrows = new ConcurrentHashMap<>();
    private volatile boolean enabled = true;
    private RailJob job = null;  // chỉ đọc/ghi trên main thread

    private FireBowRuntime() {}

    public boolean isEnabled() { return enabled; }
    public void    toggle()    { enabled = !enabled; }
    public boolean isBusy()    { return job != null; }

    public boolean isDuplicateArrow(int id) {
        Long t = acceptedArrows.get(id);
        return t != null && (System.currentTimeMillis() - t) < ARROW_TTL;
    }

    // ─── HEAD sendMovementPackets: áp góc để movement packet mang đúng rotation ──

    public void beforeSync() {
        if (!enabled) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        RotationUtil.applyBeforeSync(mc.player);
    }

    // ─── Arrow tick: nhận yêu cầu đặt rail ──────────────────────────────────

    public void requestRail(MinecraftClient mc, int arrowId, BlockPos railPos) {
        if (job != null) return;
        if (InventoryUtil.findAny(Items.RAIL, Items.POWERED_RAIL).isMissing()) return;

        acceptedArrows.put(arrowId, System.currentTimeMillis());
        AsyncRunner.runDelayed(() -> acceptedArrows.remove(arrowId), ARROW_TTL);

        job = new RailJob(railPos);
        InteractionUtil.prepareRailPlacement(mc, railPos);
    }

    // ─── END_CLIENT_TICK ─────────────────────────────────────────────────────

    public void onClientTick(MinecraftClient mc) {
        try {
            if (mc.player == null || mc.world == null) {
                job = null;
                return;
            }
            if (!enabled) {
                if (job != null) abort(mc);
                return;
            }
            if (job != null) stepJob(mc);
        } finally {
            RotationUtil.endOfTick();
        }
    }

    private void stepJob(MinecraftClient mc) {
        RailJob j = job;
        j.ticks++;
        j.totalTicks++;
        if (j.totalTicks > MAX_JOB_TICKS) { abort(mc); return; }

        boolean railThere = isRail(mc, j.pos);

        switch (j.phase) {
            case SEND -> {
                if (railThere) { enter(j, Phase.VERIFY, windowTicks(mc)); return; }

                SearchResult rail = InventoryUtil.findAny(Items.RAIL, Items.POWERED_RAIL);
                if (rail.isMissing()) { abort(mc); return; }

                switch (InteractionUtil.executeRail(mc, j.pos, rail.slot)) {
                    case SENT      -> { j.attempts++; enter(j, Phase.VERIFY, windowTicks(mc)); }
                    case NOT_READY -> { if (j.ticks > MAX_WAIT) abort(mc); }
                    case INVALID   -> abort(mc);
                }
            }

            case VERIFY -> {
                if (!railThere) { revert(mc, j); return; }
                // Rail vẫn còn sau window tick → server đã accept → đặt cart ngay
                // Hoặc nếu window = 1 tick thì check ngay tick đầu tiên
                if (j.ticks >= j.window || (railThere && j.window <= 1)) {
                    enter(j, Phase.CART, 0);
                }
            }

            case CART -> {
                if (!railThere) { revert(mc, j); return; }

                SearchResult cart = InventoryUtil.findItem(Items.TNT_MINECART);
                if (cart.isMissing()) { job = null; return; }

                if (InteractionUtil.placeCartDirect(mc, j.pos, cart.slot)) {
                    job = null;
                } else if (j.ticks > MAX_WAIT) {
                    abort(mc);
                }
            }
        }
    }

    /** Rail bị server revert → đặt lại từ đầu, hoặc bỏ nếu đã hết lượt. */
    private void revert(MinecraftClient mc, RailJob j) {
        if (j.attempts >= MAX_PLACE_ATTEMPTS) { abort(mc); return; }
        InteractionUtil.prepareRailPlacement(mc, j.pos);
        enter(j, Phase.SEND, 0);
    }

    private static void enter(RailJob j, Phase phase, int window) {
        j.phase  = phase;
        j.ticks  = 0;
        j.window = window;
    }

    private void abort(MinecraftClient mc) {
        job = null;
        InteractionUtil.abort(mc);
    }

    private static boolean isRail(MinecraftClient mc, BlockPos pos) {
        BlockState s = mc.world.getBlockState(pos);
        return s.isOf(Blocks.RAIL) || s.isOf(Blocks.POWERED_RAIL);
    }

    /**
     * Ping/50ms + 1 tick đệm.
     * Server revert đến client trong 1 round-trip = ping ms = ping/50 tick.
     * Sau đó 1 tick buffer để đảm bảo packet đã xử lý xong → đặt cart ngay.
     * min 1 tick (ping < 50ms), max 6 tick (ping 250ms+).
     */
    private static int windowTicks(MinecraftClient mc) {
        long ping = PingUtil.getPingMs(mc);
        return (int) Math.max(1, Math.round(ping / 50.0) + 1);
    }
}
