package com.firebow.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/**
 * InteractionUtil v6.
 *
 * RAIL: prepareRailPlacement (tick N) → executeRail (tick N+1, sau beforeSync).
 *       executeRail trả NOT_READY nếu rotation chưa áp hoặc player đã ra khỏi reach,
 *       để FireBowRuntime thử lại thay vì bắn interact sai.
 * CART: placeCartDirect giữ nguyên logic, trả false nếu ngoài reach.
 */
public final class InteractionUtil {
    private InteractionUtil() {}

    public enum Result { SENT, NOT_READY, INVALID }

    public static void prepareRailPlacement(MinecraftClient mc, BlockPos railPos) {
        ClientPlayerEntity p = mc.player;
        if (p == null) return;
        RotationUtil.setPendingTarget(p, RotationUtil.calcHitVec(railPos.down(), Direction.UP));
    }

    public static Result executeRail(MinecraftClient mc, BlockPos railPos, int railSlot) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null) return Result.INVALID;

        BlockPos ground = railPos.down();
        if (!mc.world.getBlockState(railPos).isAir())      return Result.INVALID;
        if (!PlacementCalc.isSolidGround(mc.world, ground)) return Result.INVALID;

        // Knockback có thể đẩy player ra xa giữa tick arrow và tick này
        if (!inReach(p, railPos)) return Result.NOT_READY;

        // Movement packet tick này phải đã mang góc đúng
        if (!RotationUtil.wasApplied()) return Result.NOT_READY;

        Vec3d hitVec = RotationUtil.calcHitVec(ground, Direction.UP);

        int origSlot = p.getInventory().selectedSlot;
        p.getInventory().selectedSlot = railSlot;
        p.swingHand(Hand.MAIN_HAND);
        mc.interactionManager.interactBlock(p, Hand.MAIN_HAND,
            new BlockHitResult(hitVec, Direction.UP, ground, false));
        p.getInventory().selectedSlot = origSlot;

        RotationUtil.restoreAfterInteract(p);
        return Result.SENT;
    }

    // ─── Cart ────────────────────────────────────────────────────────────────

    public static boolean placeCartDirect(MinecraftClient mc, BlockPos railPos, int cartSlot) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.interactionManager == null) return false;

        Vec3d eye     = p.getEyePos();
        Vec3d vel     = p.getVelocity();
        double vy     = p.isOnGround() ? vel.y : (vel.y - 0.08) * 0.98;
        Vec3d eyeNext = eye.add(vel.x, vy, vel.z);
        Vec3d center  = Vec3d.ofCenter(railPos);

        double distCur  = eye.squaredDistanceTo(center);
        double distNext = eyeNext.squaredDistanceTo(center);
        if (Math.max(distCur, distNext) > 4.5 * 4.5) return false;

        Vec3d   hitVec   = RotationUtil.calcHitVec(railPos, Direction.UP);
        float[] rot      = RotationUtil.calcRotationFromEye(eyeNext, hitVec);
        float   savedYaw = p.getYaw();
        float   savedPit = p.getPitch();

        RotationUtil.applyRaw(p, rot);

        int origSlot = p.getInventory().selectedSlot;
        p.getInventory().selectedSlot = cartSlot;
        p.swingHand(Hand.MAIN_HAND);
        mc.interactionManager.interactBlock(p, Hand.MAIN_HAND,
            new BlockHitResult(hitVec, Direction.UP, railPos, false));
        p.getInventory().selectedSlot = origSlot;

        RotationUtil.applyRaw(p, new float[]{ savedYaw, savedPit });
        return true;
    }

    // ─── Utils ───────────────────────────────────────────────────────────────

    public static void abort(MinecraftClient mc) {
        RotationUtil.abort(mc == null ? null : mc.player);
    }

    public static boolean inReach(ClientPlayerEntity p, BlockPos pos) {
        return inReachFrom(p.getEyePos(), pos);
    }

    public static boolean inReachFrom(Vec3d eyePos, BlockPos pos) {
        return eyePos.squaredDistanceTo(Vec3d.ofCenter(pos)) <= 4.5 * 4.5;
    }
}
